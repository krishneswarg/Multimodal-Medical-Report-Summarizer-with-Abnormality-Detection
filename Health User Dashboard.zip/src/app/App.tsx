import { useState } from 'react';
import { FileUpload } from './components/FileUpload';
import { ReportSummary } from './components/ReportSummary';
import { PlainLanguageSummary } from './components/PlainLanguageSummary';
import { RiskAssessment } from './components/RiskAssessment';
import { HealthGuidance } from './components/HealthGuidance';
import { MentalHealthScore } from './components/MentalHealthScore';
import { VitalsTracker } from './components/VitalsTracker';
import { BodyAnalysis } from './components/BodyAnalysis';
import { DownloadReport } from './components/DownloadReport';
import { Activity, FileText, Clock, CheckCircle } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';

function App() {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  const handleFileUpload = (file: File) => {
    setUploadedFile(file);
    setIsAnalyzing(true);
    
    // Simulate analysis process
    setTimeout(() => {
      setIsAnalyzing(false);
      setAnalysisComplete(true);
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg p-2.5">
              <Activity className="h-7 w-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Multimodal Medical Report Analyzer</h1>
              <p className="text-sm text-gray-600">AI-powered health report analysis and guidance</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!analysisComplete ? (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-2">Upload Your Medical Report</h2>
              <p className="text-gray-600">
                Upload lab reports, radiology notes, or other medical documents in PDF or image format
              </p>
            </div>

            <FileUpload onFileUpload={handleFileUpload} />

            {isAnalyzing && (
              <div className="bg-white rounded-lg border-2 border-blue-200 p-8">
                <div className="flex items-center justify-center gap-4 mb-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  <p className="text-lg font-semibold">Analyzing your medical report...</p>
                </div>
                <div className="space-y-3 max-w-md mx-auto">
                  <div className="flex items-center gap-3 text-sm text-gray-600">
                    <Clock className="h-4 w-4" />
                    <span>Extracting text and data from document</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-gray-600">
                    <Clock className="h-4 w-4" />
                    <span>Identifying medical parameters and values</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-gray-600">
                    <Clock className="h-4 w-4" />
                    <span>Calculating health risks and generating insights</span>
                  </div>
                </div>
                {uploadedFile && (
                  <p className="text-sm text-gray-500 mt-4 text-center">
                    Processing: {uploadedFile.name}
                  </p>
                )}
              </div>
            )}

            {/* Information Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <div className="bg-white p-6 rounded-lg border border-gray-200">
                <FileText className="h-8 w-8 text-blue-500 mb-3" />
                <h3 className="font-semibold mb-2">Supported Formats</h3>
                <p className="text-sm text-gray-600">
                  Upload PDF documents or images (JPG, PNG) of lab reports and medical records
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg border border-gray-200">
                <Activity className="h-8 w-8 text-green-500 mb-3" />
                <h3 className="font-semibold mb-2">Instant Analysis</h3>
                <p className="text-sm text-gray-600">
                  Get plain-language summaries and flagged abnormalities in seconds
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg border border-gray-200">
                <CheckCircle className="h-8 w-8 text-purple-500 mb-3" />
                <h3 className="font-semibold mb-2">Personalized Guidance</h3>
                <p className="text-sm text-gray-600">
                  Receive health recommendations and risk assessments based on your results
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Success Banner */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <div>
                  <h3 className="font-semibold text-green-900">Analysis Complete</h3>
                  <p className="text-sm text-green-700">
                    Your medical report has been successfully analyzed. Review the findings below.
                  </p>
                </div>
              </div>
            </div>

            {/* Tabs for organized content */}
            <Tabs defaultValue="summary" className="w-full">
              <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5">
                <TabsTrigger value="summary">Summary</TabsTrigger>
                <TabsTrigger value="vitals">Vitals</TabsTrigger>
                <TabsTrigger value="risks">Risks</TabsTrigger>
                <TabsTrigger value="guidance">Guidance</TabsTrigger>
                <TabsTrigger value="wellbeing">Well-being</TabsTrigger>
              </TabsList>

              <TabsContent value="summary" className="space-y-6 mt-6">
                <PlainLanguageSummary />
                <ReportSummary />
                <BodyAnalysis />
                <DownloadReport />
              </TabsContent>

              <TabsContent value="vitals" className="space-y-6 mt-6">
                <VitalsTracker />
                <ReportSummary />
              </TabsContent>

              <TabsContent value="risks" className="space-y-6 mt-6">
                <RiskAssessment />
                <BodyAnalysis />
              </TabsContent>

              <TabsContent value="guidance" className="space-y-6 mt-6">
                <HealthGuidance />
                <DownloadReport />
              </TabsContent>

              <TabsContent value="wellbeing" className="space-y-6 mt-6">
                <MentalHealthScore />
                <HealthGuidance />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-sm text-gray-500 text-center">
            <strong>Medical Disclaimer:</strong> This tool is for informational purposes only and does not constitute medical advice. 
            Always consult with qualified healthcare professionals for diagnosis and treatment decisions.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;