import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Apple, Dumbbell, Pill, Stethoscope } from 'lucide-react';

export function HealthGuidance() {
  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-4">Personalized Health Guidance</h3>
      
      <Tabs defaultValue="diet" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="diet">
            <Apple className="h-4 w-4 mr-2" />
            Diet
          </TabsTrigger>
          <TabsTrigger value="exercise">
            <Dumbbell className="h-4 w-4 mr-2" />
            Exercise
          </TabsTrigger>
          <TabsTrigger value="medication">
            <Pill className="h-4 w-4 mr-2" />
            Medication
          </TabsTrigger>
          <TabsTrigger value="monitoring">
            <Stethoscope className="h-4 w-4 mr-2" />
            Monitoring
          </TabsTrigger>
        </TabsList>

        <TabsContent value="diet" className="space-y-4 mt-4">
          <div className="space-y-3">
            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-semibold text-green-900 mb-2">For Blood Sugar Control</h4>
              <ul className="text-sm text-green-800 space-y-1 ml-4 list-disc">
                <li>Choose whole grains over refined carbohydrates</li>
                <li>Limit sugary drinks and desserts</li>
                <li>Include more fiber-rich foods (vegetables, legumes)</li>
                <li>Practice portion control with carbohydrates</li>
              </ul>
            </div>
            
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">For Cholesterol Management</h4>
              <ul className="text-sm text-blue-800 space-y-1 ml-4 list-disc">
                <li>Reduce saturated and trans fats</li>
                <li>Eat more omega-3 rich foods (fish, nuts, seeds)</li>
                <li>Increase soluble fiber intake (oats, beans, apples)</li>
                <li>Choose lean proteins and plant-based options</li>
              </ul>
            </div>

            <div className="p-4 bg-orange-50 rounded-lg">
              <h4 className="font-semibold text-orange-900 mb-2">For Anemia</h4>
              <ul className="text-sm text-orange-800 space-y-1 ml-4 list-disc">
                <li>Include iron-rich foods (red meat, spinach, lentils)</li>
                <li>Pair iron sources with vitamin C for better absorption</li>
                <li>Consider fortified cereals and breads</li>
              </ul>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="exercise" className="space-y-4 mt-4">
          <div className="space-y-3">
            <div className="p-4 bg-purple-50 rounded-lg">
              <h4 className="font-semibold text-purple-900 mb-2">Recommended Activities</h4>
              <ul className="text-sm text-purple-800 space-y-2 ml-4 list-disc">
                <li><strong>Aerobic Exercise:</strong> 150 minutes of moderate activity per week (brisk walking, cycling, swimming)</li>
                <li><strong>Strength Training:</strong> 2-3 sessions per week focusing on major muscle groups</li>
                <li><strong>Flexibility:</strong> Daily stretching or yoga to improve mobility</li>
                <li><strong>Daily Movement:</strong> Take breaks from sitting every hour, aim for 7,000-10,000 steps daily</li>
              </ul>
            </div>
            
            <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
              <p className="text-sm text-yellow-900">
                <strong>Important:</strong> Start slowly and gradually increase intensity. Consult your doctor before 
                starting any new exercise program, especially given your current health markers.
              </p>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="medication" className="space-y-4 mt-4">
          <div className="p-4 bg-red-50 rounded-lg border border-red-200">
            <p className="text-sm text-red-900 mb-3">
              <strong>Disclaimer:</strong> This is not a prescription. Always consult with your healthcare provider 
              before starting, stopping, or changing any medication.
            </p>
          </div>
          
          <div className="space-y-3">
            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-semibold mb-2">Potential Medications Your Doctor May Consider</h4>
              <ul className="text-sm text-gray-700 space-y-2 ml-4 list-disc">
                <li><strong>For High Blood Sugar:</strong> Metformin or other glucose-lowering medications</li>
                <li><strong>For High Cholesterol:</strong> Statins or other lipid-lowering agents</li>
                <li><strong>For Anemia:</strong> Iron supplements with or without vitamin B12/folate</li>
              </ul>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-4 mt-4">
          <div className="space-y-3">
            <div className="p-4 bg-indigo-50 rounded-lg">
              <h4 className="font-semibold text-indigo-900 mb-2">Regular Monitoring Schedule</h4>
              <ul className="text-sm text-indigo-800 space-y-2 ml-4 list-disc">
                <li><strong>Blood Glucose:</strong> Test fasting levels every 3 months initially</li>
                <li><strong>Lipid Panel:</strong> Recheck cholesterol levels in 3-6 months</li>
                <li><strong>Complete Blood Count:</strong> Follow up in 6-8 weeks to reassess hemoglobin</li>
                <li><strong>Blood Pressure:</strong> Monitor at home weekly if available</li>
                <li><strong>Weight:</strong> Track weekly to monitor progress</li>
              </ul>
            </div>

            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-semibold mb-2">Warning Signs to Watch For</h4>
              <p className="text-sm text-gray-700 mb-2">Seek immediate medical attention if you experience:</p>
              <ul className="text-sm text-gray-700 space-y-1 ml-4 list-disc">
                <li>Severe chest pain or pressure</li>
                <li>Extreme fatigue or weakness</li>
                <li>Persistent headaches or vision changes</li>
                <li>Unusual bruising or bleeding</li>
              </ul>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
}
