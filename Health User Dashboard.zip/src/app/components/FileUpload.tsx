import { Upload, FileText, Image } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';

interface FileUploadProps {
  onFileUpload: (file: File) => void;
}

export function FileUpload({ onFileUpload }: FileUploadProps) {
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) onFileUpload(file);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) onFileUpload(file);
  };

  return (
    <Card className="p-8">
      <div
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
        className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-blue-400 transition-colors"
      >
        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <h3 className="text-lg font-semibold mb-2">Upload Medical Report</h3>
        <p className="text-gray-500 mb-4">
          Drag and drop your medical report or click to browse
        </p>
        <div className="flex items-center justify-center gap-4 mb-4">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <FileText className="h-4 w-4" />
            <span>PDF</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Image className="h-4 w-4" />
            <span>Image</span>
          </div>
        </div>
        <label htmlFor="file-upload">
          <Button asChild>
            <span className="cursor-pointer">Select File</span>
          </Button>
        </label>
        <input
          id="file-upload"
          type="file"
          accept=".pdf,image/*"
          onChange={handleFileInput}
          className="hidden"
        />
      </div>
    </Card>
  );
}
