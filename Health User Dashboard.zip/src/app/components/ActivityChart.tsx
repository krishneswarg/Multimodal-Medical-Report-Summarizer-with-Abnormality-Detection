import { Card } from './ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const data = [
  { date: 'Mon', steps: 8234, calories: 2100 },
  { date: 'Tue', steps: 10521, calories: 2400 },
  { date: 'Wed', steps: 7894, calories: 1950 },
  { date: 'Thu', steps: 12456, calories: 2650 },
  { date: 'Fri', steps: 9345, calories: 2200 },
  { date: 'Sat', steps: 15234, calories: 2850 },
  { date: 'Sun', steps: 11789, calories: 2500 },
];

export function ActivityChart() {
  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">Weekly Activity</h3>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis dataKey="date" stroke="#6b7280" />
          <YAxis yAxisId="left" stroke="#6b7280" />
          <YAxis yAxisId="right" orientation="right" stroke="#6b7280" />
          <Tooltip />
          <Legend />
          <Line
            yAxisId="left"
            type="monotone"
            dataKey="steps"
            stroke="#3b82f6"
            strokeWidth={2}
            dot={{ r: 4 }}
            name="Steps"
          />
          <Line
            yAxisId="right"
            type="monotone"
            dataKey="calories"
            stroke="#f59e0b"
            strokeWidth={2}
            dot={{ r: 4 }}
            name="Calories"
          />
        </LineChart>
      </ResponsiveContainer>
    </Card>
  );
}
