import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

interface Finding {
  parameter: string;
  value: string;
  normalRange: string;
  status: 'normal' | 'low' | 'medium' | 'high';
}

const findings: Finding[] = [
  { parameter: 'Hemoglobin', value: '11.2 g/dL', normalRange: '12-16 g/dL', status: 'low' },
  { parameter: 'White Blood Cells', value: '7,500/μL', normalRange: '4,000-11,000/μL', status: 'normal' },
  { parameter: 'Glucose (Fasting)', value: '145 mg/dL', normalRange: '70-100 mg/dL', status: 'high' },
  { parameter: 'Total Cholesterol', value: '240 mg/dL', normalRange: '<200 mg/dL', status: 'high' },
  { parameter: 'HDL Cholesterol', value: '45 mg/dL', normalRange: '>40 mg/dL', status: 'normal' },
  { parameter: 'LDL Cholesterol', value: '160 mg/dL', normalRange: '<100 mg/dL', status: 'high' },
  { parameter: 'Triglycerides', value: '175 mg/dL', normalRange: '<150 mg/dL', status: 'medium' },
  { parameter: 'Creatinine', value: '1.0 mg/dL', normalRange: '0.7-1.3 mg/dL', status: 'normal' },
];

const getStatusBadge = (status: Finding['status']) => {
  switch (status) {
    case 'normal':
      return <Badge className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Normal</Badge>;
    case 'low':
      return <Badge className="bg-yellow-500"><AlertTriangle className="h-3 w-3 mr-1" />Low</Badge>;
    case 'medium':
      return <Badge className="bg-orange-500"><AlertTriangle className="h-3 w-3 mr-1" />Medium</Badge>;
    case 'high':
      return <Badge className="bg-red-500"><XCircle className="h-3 w-3 mr-1" />High</Badge>;
  }
};

export function ReportSummary() {
  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-4">Lab Results Summary</h3>
      <p className="text-gray-600 mb-6">
        Your report has been analyzed. Below are the key findings with abnormal values flagged for your attention.
      </p>
      
      <div className="space-y-3">
        {findings.map((finding, index) => (
          <div
            key={index}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <div className="flex-1">
              <p className="font-medium">{finding.parameter}</p>
              <p className="text-sm text-gray-500">Normal: {finding.normalRange}</p>
            </div>
            <div className="flex items-center gap-4">
              <p className="font-semibold">{finding.value}</p>
              {getStatusBadge(finding.status)}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
