import { Card } from './ui/card';
import { AlertCircle, Info } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

export function PlainLanguageSummary() {
  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-4">Plain Language Summary</h3>
      
      <Alert className="mb-4 border-blue-200 bg-blue-50">
        <Info className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-900">
          This summary explains your results in simple terms. Always consult with your healthcare provider for medical advice.
        </AlertDescription>
      </Alert>

      <div className="space-y-4">
        <div>
          <h4 className="font-semibold mb-2 flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-500" />
            Areas Requiring Attention
          </h4>
          <ul className="space-y-2 ml-7 text-gray-700">
            <li className="leading-relaxed">
              <strong>Blood Sugar (Glucose):</strong> Your fasting glucose level is 145 mg/dL, which is higher than normal (70-100 mg/dL). 
              This may indicate prediabetes or diabetes. Your doctor may recommend lifestyle changes or medication.
            </li>
            <li className="leading-relaxed">
              <strong>Cholesterol:</strong> Your total cholesterol (240 mg/dL) and LDL cholesterol (160 mg/dL) are elevated. 
              High cholesterol can increase your risk of heart disease. Consider dietary changes and regular exercise.
            </li>
            <li className="leading-relaxed">
              <strong>Hemoglobin:</strong> Your hemoglobin level is slightly low at 11.2 g/dL (normal: 12-16 g/dL). 
              This could indicate anemia. Your doctor may recommend iron supplements or further testing.
            </li>
          </ul>
        </div>

        <div className="pt-4 border-t">
          <h4 className="font-semibold mb-2 text-green-700">Healthy Parameters</h4>
          <p className="text-gray-700 leading-relaxed">
            Your white blood cell count, HDL cholesterol, and kidney function (creatinine) are all within normal ranges, 
            which is a positive sign for your overall health.
          </p>
        </div>

        <div className="pt-4 border-t">
          <h4 className="font-semibold mb-2">Next Steps</h4>
          <p className="text-gray-700 leading-relaxed">
            Schedule a follow-up appointment with your healthcare provider to discuss these results and develop 
            a personalized treatment plan. They may recommend additional tests, lifestyle modifications, or medications.
          </p>
        </div>
      </div>
    </Card>
  );
}
