import { Card } from './ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const data = [
  { day: 'Mon', deep: 2.1, light: 3.8, rem: 1.5 },
  { day: 'Tue', deep: 1.9, light: 4.2, rem: 1.3 },
  { day: 'Wed', deep: 2.3, light: 3.5, rem: 1.7 },
  { day: 'Thu', deep: 2.0, light: 4.0, rem: 1.4 },
  { day: 'Fri', deep: 1.8, light: 3.9, rem: 1.2 },
  { day: 'Sat', deep: 2.5, light: 4.3, rem: 1.8 },
  { day: 'Sun', deep: 2.2, light: 4.1, rem: 1.6 },
];

export function SleepChart() {
  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">Sleep Analysis</h3>
      <ResponsiveContainer width="100%" height={250}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis dataKey="day" stroke="#6b7280" />
          <YAxis stroke="#6b7280" label={{ value: 'Hours', angle: -90, position: 'insideLeft' }} />
          <Tooltip />
          <Legend />
          <Bar dataKey="deep" stackId="a" fill="#6366f1" name="Deep Sleep" />
          <Bar dataKey="light" stackId="a" fill="#8b5cf6" name="Light Sleep" />
          <Bar dataKey="rem" stackId="a" fill="#a855f7" name="REM Sleep" />
        </BarChart>
      </ResponsiveContainer>
    </Card>
  );
}
