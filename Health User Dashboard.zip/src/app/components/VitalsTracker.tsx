import { Card } from './ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

const bloodPressureData = [
  { date: 'Jan 1', systolic: 138, diastolic: 88 },
  { date: 'Jan 8', systolic: 142, diastolic: 90 },
  { date: 'Jan 15', systolic: 135, diastolic: 85 },
  { date: 'Jan 22', systolic: 140, diastolic: 89 },
  { date: 'Jan 29', systolic: 136, diastolic: 86 },
  { date: 'Feb 5', systolic: 132, diastolic: 84 },
  { date: 'Feb 12', systolic: 128, diastolic: 82 },
];

const glucoseData = [
  { date: 'Jan 1', fasting: 145, postMeal: 180 },
  { date: 'Jan 8', fasting: 148, postMeal: 185 },
  { date: 'Jan 15', fasting: 142, postMeal: 175 },
  { date: 'Jan 22', fasting: 138, postMeal: 170 },
  { date: 'Jan 29', fasting: 135, postMeal: 165 },
  { date: 'Feb 5', fasting: 132, postMeal: 160 },
  { date: 'Feb 12', fasting: 128, postMeal: 155 },
];

const weightData = [
  { date: 'Jan 1', weight: 85.2, bmi: 28.5 },
  { date: 'Jan 8', weight: 84.8, bmi: 28.3 },
  { date: 'Jan 15', weight: 84.5, bmi: 28.2 },
  { date: 'Jan 22', weight: 84.0, bmi: 28.0 },
  { date: 'Jan 29', weight: 83.7, bmi: 27.9 },
  { date: 'Feb 5', weight: 83.2, bmi: 27.7 },
  { date: 'Feb 12', weight: 82.8, bmi: 27.6 },
];

export function VitalsTracker() {
  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-4">Vitals Tracking</h3>
      
      <Tabs defaultValue="bp" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="bp">Blood Pressure</TabsTrigger>
          <TabsTrigger value="glucose">Blood Glucose</TabsTrigger>
          <TabsTrigger value="weight">Weight & BMI</TabsTrigger>
        </TabsList>

        <TabsContent value="bp" className="mt-4">
          <div className="mb-4">
            <p className="text-sm text-gray-600">
              Target: &lt;120/80 mmHg (Systolic/Diastolic)
            </p>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={bloodPressureData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="date" stroke="#6b7280" />
              <YAxis stroke="#6b7280" domain={[70, 150]} />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="systolic"
                stroke="#ef4444"
                strokeWidth={2}
                dot={{ r: 4 }}
                name="Systolic"
              />
              <Line
                type="monotone"
                dataKey="diastolic"
                stroke="#3b82f6"
                strokeWidth={2}
                dot={{ r: 4 }}
                name="Diastolic"
              />
            </LineChart>
          </ResponsiveContainer>
        </TabsContent>

        <TabsContent value="glucose" className="mt-4">
          <div className="mb-4">
            <p className="text-sm text-gray-600">
              Target: Fasting &lt;100 mg/dL, Post-meal &lt;140 mg/dL
            </p>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={glucoseData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="date" stroke="#6b7280" />
              <YAxis stroke="#6b7280" domain={[100, 200]} />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="fasting"
                stroke="#f59e0b"
                strokeWidth={2}
                dot={{ r: 4 }}
                name="Fasting"
              />
              <Line
                type="monotone"
                dataKey="postMeal"
                stroke="#10b981"
                strokeWidth={2}
                dot={{ r: 4 }}
                name="Post-Meal"
              />
            </LineChart>
          </ResponsiveContainer>
        </TabsContent>

        <TabsContent value="weight" className="mt-4">
          <div className="mb-4">
            <p className="text-sm text-gray-600">
              Target BMI: 18.5-24.9 (Normal weight)
            </p>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={weightData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="date" stroke="#6b7280" />
              <YAxis yAxisId="left" stroke="#6b7280" domain={[75, 90]} label={{ value: 'kg', angle: -90, position: 'insideLeft' }} />
              <YAxis yAxisId="right" orientation="right" stroke="#6b7280" domain={[25, 32]} label={{ value: 'BMI', angle: 90, position: 'insideRight' }} />
              <Tooltip />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="weight"
                stroke="#8b5cf6"
                strokeWidth={2}
                dot={{ r: 4 }}
                name="Weight (kg)"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="bmi"
                stroke="#ec4899"
                strokeWidth={2}
                dot={{ r: 4 }}
                name="BMI"
              />
            </LineChart>
          </ResponsiveContainer>
        </TabsContent>
      </Tabs>
    </Card>
  );
}
