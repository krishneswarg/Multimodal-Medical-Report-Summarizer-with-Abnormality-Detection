import { Card } from './ui/card';
import { Button } from './ui/button';
import { Download, FileJson, FileText } from 'lucide-react';

export function DownloadReport() {
  const downloadJSON = () => {
    const reportData = {
      patientInfo: {
        reportDate: new Date().toISOString(),
        analysisDate: new Date().toISOString(),
      },
      findings: [
        { parameter: 'Hemoglobin', value: '11.2 g/dL', normalRange: '12-16 g/dL', status: 'low' },
        { parameter: 'Glucose', value: '145 mg/dL', normalRange: '70-100 mg/dL', status: 'high' },
        { parameter: 'Total Cholesterol', value: '240 mg/dL', normalRange: '<200 mg/dL', status: 'high' },
        { parameter: 'LDL Cholesterol', value: '160 mg/dL', normalRange: '<100 mg/dL', status: 'high' },
      ],
      riskAssessment: {
        cardiovascularDisease: 65,
        type2Diabetes: 58,
        metabolicSyndrome: 45,
        stroke: 32,
      },
      recommendations: {
        diet: 'Focus on whole grains, reduce saturated fats, increase fiber',
        exercise: '150 minutes moderate aerobic activity per week',
        monitoring: 'Recheck glucose and lipids in 3 months',
      },
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medical-report-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadPDF = () => {
    // Simulate PDF download (in a real app, this would generate an actual PDF)
    alert('PDF generation would be implemented with a library like jsPDF or pdfmake. This is a simulation.');
  };

  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-4">Download Reports</h3>
      <p className="text-gray-600 mb-6">
        Download your complete medical report analysis in structured formats for your records or to share with healthcare providers.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-400 transition-colors">
          <FileJson className="h-8 w-8 text-blue-500 mb-3" />
          <h4 className="font-semibold mb-2">JSON Format</h4>
          <p className="text-sm text-gray-600 mb-4">
            Structured data format ideal for integration with other health apps or electronic health records.
          </p>
          <Button onClick={downloadJSON} className="w-full">
            <Download className="h-4 w-4 mr-2" />
            Download JSON
          </Button>
        </div>

        <div className="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-400 transition-colors">
          <FileText className="h-8 w-8 text-red-500 mb-3" />
          <h4 className="font-semibold mb-2">PDF Format</h4>
          <p className="text-sm text-gray-600 mb-4">
            Printable report with all findings, summaries, and recommendations in a readable format.
          </p>
          <Button onClick={downloadPDF} className="w-full">
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
        </div>
      </div>

      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
        <p className="text-xs text-gray-600">
          <strong>Privacy Notice:</strong> Your medical data is processed locally in your browser. 
          No information is stored on external servers. Downloaded files contain sensitive health information - 
          please store them securely.
        </p>
      </div>
    </Card>
  );
}
