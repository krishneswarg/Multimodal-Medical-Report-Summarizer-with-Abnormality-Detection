import { Card } from './ui/card';
import { Brain, Heart, Smile, Moon } from 'lucide-react';
import { Progress } from './ui/progress';

const mentalHealthMetrics = [
  { name: 'Stress Level', score: 72, icon: Brain, target: 'Target: <50', color: 'text-orange-500' },
  { name: 'Sleep Quality', score: 65, icon: Moon, target: 'Target: >80', color: 'text-purple-500' },
  { name: 'Emotional Well-being', score: 78, icon: Heart, target: 'Target: >75', color: 'text-pink-500' },
  { name: 'Life Satisfaction', score: 82, icon: Smile, target: 'Target: >75', color: 'text-green-500' },
];

export function MentalHealthScore() {
  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-4">Mental Health & Well-being</h3>
      <p className="text-gray-600 mb-6">
        Chronic health conditions can impact mental health. Here's your current well-being assessment:
      </p>

      <div className="space-y-6">
        {mentalHealthMetrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <div key={metric.name}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Icon className={`h-5 w-5 ${metric.color}`} />
                  <span className="font-medium">{metric.name}</span>
                </div>
                <div className="text-right">
                  <span className="font-semibold">{metric.score}/100</span>
                  <p className="text-xs text-gray-500">{metric.target}</p>
                </div>
              </div>
              <Progress value={metric.score} className="h-2" />
            </div>
          );
        })}
      </div>

      <div className="mt-6 space-y-3">
        <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
          <h4 className="font-semibold text-yellow-900 mb-2">Recommendations</h4>
          <ul className="text-sm text-yellow-800 space-y-1 ml-4 list-disc">
            <li>Practice stress-reduction techniques (meditation, deep breathing)</li>
            <li>Maintain a consistent sleep schedule (7-9 hours nightly)</li>
            <li>Consider talking to a mental health professional</li>
            <li>Engage in activities you enjoy regularly</li>
          </ul>
        </div>

        <div className="p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-900">
            <strong>Remember:</strong> Managing chronic conditions can be stressful. It's important to address both 
            physical and mental health for overall well-being.
          </p>
        </div>
      </div>
    </Card>
  );
}
