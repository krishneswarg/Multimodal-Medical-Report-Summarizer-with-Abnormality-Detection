import { Card } from './ui/card';
import { User, AlertTriangle, CheckCircle } from 'lucide-react';

const bodyMetrics = [
  { area: 'Cardiovascular System', status: 'concern', findings: ['Elevated cholesterol', 'High blood glucose'] },
  { area: 'Blood & Circulation', status: 'concern', findings: ['Low hemoglobin (anemia)'] },
  { area: 'Kidney Function', status: 'normal', findings: ['Normal creatinine levels'] },
  { area: 'Immune System', status: 'normal', findings: ['WBC count within range'] },
  { area: 'Metabolic Health', status: 'concern', findings: ['Elevated triglycerides', 'High glucose'] },
];

export function BodyAnalysis() {
  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-4">Body Systems Analysis</h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Body Diagram */}
        <div className="flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-8">
          <User className="h-64 w-64 text-blue-300" strokeWidth={1} />
          <p className="text-sm text-gray-600 mt-4 text-center">
            Visual representation of affected body systems
          </p>
        </div>

        {/* Systems Status */}
        <div className="space-y-4">
          {bodyMetrics.map((metric, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-start gap-3">
                {metric.status === 'concern' ? (
                  <AlertTriangle className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                )}
                <div className="flex-1">
                  <h4 className="font-semibold mb-1">{metric.area}</h4>
                  <ul className="text-sm text-gray-600 space-y-0.5">
                    {metric.findings.map((finding, idx) => (
                      <li key={idx}>• {finding}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <h4 className="font-semibold text-blue-900 mb-2">Overall Assessment</h4>
        <p className="text-sm text-blue-800">
          Your analysis shows concerns primarily in your cardiovascular and metabolic systems. The good news is that 
          kidney function and immune system markers are healthy. Focus on managing blood sugar and cholesterol through 
          lifestyle modifications and medical guidance.
        </p>
      </div>
    </Card>
  );
}
