import { Card } from './ui/card';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { time: '00:00', bpm: 62 },
  { time: '04:00', bpm: 58 },
  { time: '08:00', bpm: 72 },
  { time: '12:00', bpm: 85 },
  { time: '16:00', bpm: 78 },
  { time: '20:00', bpm: 68 },
  { time: '23:59', bpm: 64 },
];

export function HeartRateChart() {
  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">Heart Rate</h3>
      <ResponsiveContainer width="100%" height={200}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id="colorBpm" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="#ef4444" stopOpacity={0.1}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis dataKey="time" stroke="#6b7280" />
          <YAxis stroke="#6b7280" domain={[40, 100]} />
          <Tooltip />
          <Area
            type="monotone"
            dataKey="bpm"
            stroke="#ef4444"
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#colorBpm)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </Card>
  );
}
