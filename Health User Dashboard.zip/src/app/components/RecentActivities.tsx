import { Card } from './ui/card';
import { Activity, Bike, Dumbbell, PersonStanding } from 'lucide-react';

const activities = [
  { id: 1, type: 'Running', duration: '32 min', calories: 245, time: '2 hours ago', icon: PersonStanding, color: 'bg-orange-500' },
  { id: 2, type: 'Cycling', duration: '45 min', calories: 320, time: '5 hours ago', icon: Bike, color: 'bg-green-500' },
  { id: 3, type: 'Strength Training', duration: '28 min', calories: 180, time: 'Yesterday', icon: Dumbbell, color: 'bg-purple-500' },
  { id: 4, type: 'Walking', duration: '60 min', calories: 150, time: 'Yesterday', icon: Activity, color: 'bg-blue-500' },
];

export function RecentActivities() {
  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">Recent Activities</h3>
      <div className="space-y-4">
        {activities.map((activity) => {
          const Icon = activity.icon;
          return (
            <div key={activity.id} className="flex items-center gap-4">
              <div className={`rounded-full p-3 ${activity.color}`}>
                <Icon className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-medium">{activity.type}</p>
                <p className="text-sm text-gray-500">{activity.time}</p>
              </div>
              <div className="text-right">
                <p className="font-medium">{activity.duration}</p>
                <p className="text-sm text-gray-500">{activity.calories} cal</p>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
