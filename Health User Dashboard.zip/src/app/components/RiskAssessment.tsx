import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Heart, Activity, Brain, TrendingUp } from 'lucide-react';

interface RiskCategory {
  name: string;
  risk: number;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
}

const risks: RiskCategory[] = [
  { name: 'Cardiovascular Disease', risk: 65, icon: Heart, color: 'text-red-500' },
  { name: 'Type 2 Diabetes', risk: 58, icon: Activity, color: 'text-orange-500' },
  { name: 'Metabolic Syndrome', risk: 45, icon: TrendingUp, color: 'text-yellow-500' },
  { name: 'Stroke', risk: 32, icon: Brain, color: 'text-purple-500' },
];

const getRiskLevel = (risk: number) => {
  if (risk >= 60) return { label: 'High Risk', color: 'text-red-600' };
  if (risk >= 40) return { label: 'Moderate Risk', color: 'text-orange-600' };
  return { label: 'Low Risk', color: 'text-green-600' };
};

export function RiskAssessment() {
  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-4">Health Risk Assessment</h3>
      <p className="text-gray-600 mb-6">
        Based on your lab results and health indicators, here are your calculated risk levels:
      </p>
      
      <div className="space-y-6">
        {risks.map((risk) => {
          const Icon = risk.icon;
          const riskLevel = getRiskLevel(risk.risk);
          
          return (
            <div key={risk.name}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Icon className={`h-5 w-5 ${risk.color}`} />
                  <span className="font-medium">{risk.name}</span>
                </div>
                <div className="text-right">
                  <span className={`font-semibold ${riskLevel.color}`}>
                    {riskLevel.label}
                  </span>
                  <span className="text-sm text-gray-500 ml-2">({risk.risk}%)</span>
                </div>
              </div>
              <Progress value={risk.risk} className="h-2" />
            </div>
          );
        })}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <p className="text-sm text-blue-900">
          <strong>Note:</strong> These risk assessments are estimates based on your current health markers. 
          Consult with your healthcare provider for a comprehensive evaluation and personalized risk management plan.
        </p>
      </div>
    </Card>
  );
}
