import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Target, Droplet, Zap } from 'lucide-react';

const goals = [
  { name: 'Daily Steps', current: 8234, target: 10000, icon: Target, color: 'bg-blue-500' },
  { name: 'Water Intake', current: 6, target: 8, icon: Droplet, color: 'bg-cyan-500' },
  { name: 'Active Minutes', current: 45, target: 60, icon: Zap, color: 'bg-yellow-500' },
];

export function GoalsProgress() {
  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">Today's Goals</h3>
      <div className="space-y-6">
        {goals.map((goal) => {
          const percentage = (goal.current / goal.target) * 100;
          const Icon = goal.icon;
          return (
            <div key={goal.name}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`rounded-full p-1.5 ${goal.color}`}>
                    <Icon className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-sm font-medium">{goal.name}</span>
                </div>
                <span className="text-sm text-gray-600">
                  {goal.current} / {goal.target}
                </span>
              </div>
              <Progress value={percentage} className="h-2" />
            </div>
          );
        })}
      </div>
    </Card>
  );
}
